PIXIE DUST CUPS BY AMBER — WEBSITE PACKAGE

GitHub repository:
Pixiedustcupsbyamber-droid/pixiedustcupsbyamber

Files:
- index.html — public storefront
- pixiedust-logo.jpeg — business logo
- products.json — product data shown on the storefront
- admin/index.html — private CMS page
- admin/config.yml — Decap CMS configuration
- uploads/ — product photo upload folder

IMPORTANT:
The CMS uses the GitHub backend. Before /admin/ can be used on the live site, the GitHub authentication provider must be configured in Netlify. Do not share the repository with other collaborators if you want only yourself to have editing access.
